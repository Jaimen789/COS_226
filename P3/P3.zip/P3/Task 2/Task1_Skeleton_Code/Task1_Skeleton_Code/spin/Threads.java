package spin;

public class Threads extends Thread{
    
    public Threads(){}

    public void run(){
        for(int i = 0; i < 5; i++){

        }
    }

    public void start(){
        
    }

    
}
